

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'task1';
  orderType = false;
  data = ['','1','2','3','4','5','6','7','8','9','10'];
  orderTypeContain = [];
  numbers = [];
  numbers1 = [[],[],[],[]];

 
  addTextbox(num){
    this.numbers = [];
    for(let i = 1;i<=num;i++){
      this.numbers.push(i);
    }
    console.log(this.numbers)
  }

addcheckbox1(num,num1){
  this.numbers1[num] = [];
  for(let i = 1;i<=num1;i++){
    this.numbers1[num].push(i);
  }
  console.log(this.numbers1)
}
}